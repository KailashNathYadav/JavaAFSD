package com.prob1.driver;
import com.prob1.service.Construction;

public class MainSkyscraper {
	public static void main(String[] args) {
		Construction construction = new Construction();
		construction.getData();
		construction.assembledFloor();
	}
}