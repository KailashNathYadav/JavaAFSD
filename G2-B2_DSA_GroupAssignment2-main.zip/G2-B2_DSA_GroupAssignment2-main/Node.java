package com.prob2.service;

public class Node {
	public int val;
	public Node left,right;
	public Node(int val) {
		this.val = val;
		this.left = this.right = null;
	}
}
